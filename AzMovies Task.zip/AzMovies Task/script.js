// get api inside datas
const API_KEY = "api_key=9fb17d04af9aced3435cf229fc66b6df";
const BASE_URL = "https://api.themoviedb.org/3";
// const MOV_API_URL = BASE_URL + "/discover/movie?sort_by=orginal_title.desc&" + API_KEY;
let moviePage = 1;
let expectedMoviePage = 1;
let searchedMoviePage = 1;
let currentYear = new Date().getFullYear();

const LST_EXT = "&with_watch_monetization_types=flatrate";
const POP_API_URL = BASE_URL + "/discover/movie?sort_by=popularity.desc&" + API_KEY;
const MOV_API_URL = `${BASE_URL}/discover/movie?${API_KEY}&language=en-US&sort_by=orginal_title.desc&include_adult=false&include_video=false&page=`;
const GENRE_ID_URL = `${BASE_URL}/genre/movie/list?${API_KEY}&language=en-US`;
const NEW_MOVIES_URL = `${BASE_URL}/discover/movie?${API_KEY}&language=en-US&sort_by=release_date.desc&include_adult=false&include_video=false&page=`;

// https://api.themoviedb.org/3/discover/movie?api_key=9fb17d04af9aced3435cf229fc66b6df&language=en-US&sort_by=release_date.desc&


// https://image.tmdb.org/t/p/w500/1g0dhYtq4irTY1GPXvft6k4YLjm.jpg


let popularityMovies;
let movies;
let movieList;
let movieListMap;
let newMovies;
let newMoviesImgPath = [];

function sendRequest(method, url, body = null) {
    return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open(method, url);
        xhr.responseType = "json";
        xhr.onload = () => {
            if (xhr.status >= 400) {
                reject(xhr.response);
            }
            else {
                resolve(xhr.response);
            }
        };

        xhr.onerror = () => {
            reject(xhr.responseType);
        }
        xhr.send(JSON.stringify(body));
        // xhr.send(body);
    });
}

let temp = undefined;
function sr(method, url, callBack = null) {
    let xhr = new XMLHttpRequest();
    xhr.open(method, url, false);
    xhr.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            temp = JSON.parse(this.responseText);
        }
    };
    xhr.send();

    if (callBack != null) {
        callBack();
    }
}
{
    sr('GET', MOV_API_URL + moviePage + LST_EXT);
    movies = temp;
    temp = undefined;
    sr('GET', GENRE_ID_URL);
    movieList = temp;
    temp = undefined;
    sr('GET', POP_API_URL);
    popularityMovies = temp;
    temp = undefined;
    sr('GET', NEW_MOVIES_URL + expectedMoviePage + LST_EXT);
    newMovies = temp;
    temp = undefined;



    // sendRequest('GET', POP_API_URL)
    //     .then(data => { popularityMovies = data; })
    //     .catch(err => alert("Your request timed out. Re-upload the page if it's not a bother. 1"));

    // sendRequest('GET', MOV_API_URL)
    //     .then(data => { movies = data;  })
    //     .catch(err => alert("Your request timed out. Re-upload the page if it's not a bother. 2"));

    // sendRequest('GET', GENRE_ID_URL)
    //     .then(data => { movieList = data;  })
    //     .catch(err => alert("Your request timed out. Re-upload the page if it's not a bother. 3"));

    // sendRequest('GET', NEW_MOVIES_URL)
    //     .then(data => { newMovies = data; })
    //     .catch(err => alert("Your request timed out. Re-upload the page if it's not a bother. 4"));
}

// NavBar optimize
function setYears() {
    console.log(movieList);
    filterEngre();

    let content = "";

    for (let i = 74; i >= 1; i--) {
        content += `<a class="dropdown-item" href="#"  onclick="researchYear('${(1948 + i)}')">${(1948 + i)}</a>`;
    }
    document.getElementById("yearIDInMenu").innerHTML = content;

    setPopularImg();
    document.querySelector('.allMovies').innerHTML = addedNewMovies();
}
function filterEngre() {
    movieListMap = new Map();
    let tempData = movieList.genres;
    tempData.forEach(genre => {
        movieListMap.set(genre.id, genre.name);
    });
}
function fillMovies() {
    let content = ``;

    movies.results.forEach(movie => {
        let path = "";
        if (movie.poster_path == null) path = "images/placeholder.gif";
        else path = "https://image.tmdb.org/t/p/w500/" + movie.poster_path;

        content += `
        <div class="newMovie">
            <img id="${movie.id}" src="${path}">
            <div class="moviePre">
                <i class="far fa-play-circle"></i>
            </div>
            <div class="pre">
                <p>${movie.original_title}</p>
                <div class="otherPre">
                    <p>${movie.release_date.split('-')[0]}</p>
                        <i class="fa fa-star"></i>
                    <p>${movie.vote_average}</p>
                </div>
            </div>
        </div>`;
    });

    return content;
}
function fillMoviesFeatured() {
    let content = ``;

    movies.results.forEach(movie => {
        console.log(movie.release_date.split('-')[0]);
        let movieYear = Number(movie.release_date.split('-')[0]);
        if (movieYear.length != undefined) {
            if (movieYear == currentYear || movieYear == currentYear - 1) {
                let path = "";
                if (movie.poster_path == null) path = "images/placeholder.gif";
                else path = "https://image.tmdb.org/t/p/w500/" + movie.poster_path;

                content += `
            <div class="newMovie">
                <img id="${movie.id}" src="${path}">
                <div class="moviePre">
                    <i class="far fa-play-circle"></i>
                </div>
                <div class="pre">
                    <p>${movie.original_title}</p>
                    <div class="otherPre">
                        <p>${movie.release_date.split('-')[0]}</p>
                            <i class="fa fa-star"></i>
                        <p>${movie.vote_average}</p>
                    </div>
                </div>
            </div>`;
            }
        }
    });
    return content;
}
function fillGenreMovies() {
    moviePage++;
    movies = undefined;
    temp = undefined;
    sr("GET", MOV_API_URL + moviePage + LST_EXT);
    movies = temp;
    let content = ``;

    movies.results.forEach(movie => {
        let detected = false;
        for (let i = 0; i < movie.genre_ids.length; i++) {
            const genre_id = movie.genre_ids[i];
            if (genre_id == currentMovieType) {
                detected = true;
                break;
            }
        }
        if (detected) {
            let path = "";
            if (movie.poster_path == null) path = "images/placeholder.gif";
            else path = "https://image.tmdb.org/t/p/w500/" + movie.poster_path;

            content += `
            <div class="newMovie">
                <img id="${movie.id}" src="${path}">
                <div class="moviePre">
                    <i class="far fa-play-circle"></i>
                </div>
                <div class="pre">
                    <p>${movie.original_title}</p>
                    <div class="otherPre">
                        <p>${movie.release_date.split('-')[0]}</p>
                            <i class="fa fa-star"></i>
                        <p>${movie.vote_average}</p>
                    </div>
                </div>
            </div>`;
        }
    });

    if (content == "") {
        fillGenreMovies();
    }
    else {
        document.getElementById('allMovies').innerHTML += content;
    }
}
function fillYearMovies() {
    moviePage++;
    movies = undefined;
    temp = undefined;
    sr("GET", MOV_API_URL + moviePage + LST_EXT);
    movies = temp;
    let content = ``;

    movies.results.forEach(movie => {
        if (movie.release_date != undefined) {
            if (movie.release_date.split('-')[0] == currentMovieYear) {
                let path = "";
                if (movie.poster_path == null) path = "images/placeholder.gif";
                else path = "https://image.tmdb.org/t/p/w500/" + movie.poster_path;

                content += `
                <div class="newMovie">
                    <img id="${movie.id}" src="${path}">
                    <div class="moviePre">
                        <i class="far fa-play-circle"></i>
                    </div>
                    <div class="pre">
                        <p>${movie.original_title}</p>
                        <div class="otherPre">
                            <p>${movie.release_date.split('-')[0]}</p>
                                <i class="fa fa-star"></i>
                            <p>${movie.vote_average}</p>
                        </div>
                    </div>
                </div>`;
            }
        }
    });

    if (content == "") {
        fillYearMovies();
    }
    else {
        document.getElementById('allMovies').innerHTML += content;
    }
}
function searchMovie(value) {
    searchedMoviePage++;
    temp = undefined;
    sr("GET", BASE_URL + "/search/movie?" + API_KEY + "&language=en-US&query=" + value + "&page=" + searchedMoviePage + LST_EXT);
    let searchResultMovies = temp;
    let content = ``;

    console.log(searchResultMovies);

    searchResultMovies.results.forEach(movie => {
        let path = "";
        if (movie.poster_path == null) path = "images/placeholder.gif";
        else path = "https://image.tmdb.org/t/p/w500/" + movie.poster_path;

        content += `
        <div class="newMovie">
            <img id="${movie.id}" src="${path}">
            <div class="moviePre">
                <i class="far fa-play-circle"></i>
            </div>
            <div class="pre">
                <p>${movie.original_title}</p>
                <div class="otherPre">
                    <p>${movie.release_date.split('-')[0]}</p>
                        <i class="fa fa-star"></i>
                    <p>${movie.vote_average}</p>
                </div>
            </div>
        </div>`;
    });

    if (content == "" && searchedMoviePage <= searchMovie.total_pages) {
        setTimeout(() => {
            searchMovie(value);
        }, 0);
    }
    else {
        document.getElementById('allMovies').innerHTML += content;
    }
}


let genreClick = false;
let yearClick = false;
let currentMovieType = 0;
let currentMovieYear = 0;
function genreOrYearMouseEnterFunc() {
    document.getElementById("headerr").style.zIndex = "-1";
    document.querySelector('main').style.zIndex = "-1";
}
function genreOrYearMouseLeaveFunc() {
    document.getElementById("headerr").style.zIndex = "0";
    document.querySelector('main').style.zIndex = "0";
}
function searchBoxFunc(e) {
    if (e.keyCode == 13) {
        let wantedMovieName = document.getElementById('searchBox').value;
        moviePage = 0;
        let headerr = document.getElementById("headerr");
        let twoHeader = document.getElementById("twoHeader");
        headerr.innerHTML = `<h4 class="transition"><a href="#" id="homePage" style="cursor: pointer;">Home</a> / ${wantedMovieName}</h4>`;
        headerr.style.height = "auto";
        twoHeader.innerText = `Top results for: ${wantedMovieName}`;
        document.getElementById("allMovies").innerHTML = "";
        document.getElementById('showMore').style.display = "none";
        setTimeout(() => {
            searchMovie(wantedMovieName.toLowerCase());
        }, 0);
    }
}
function titleClick() {
    let headerr = document.getElementById("headerr");
    headerr.innerHTML = `
    <div class="arrows animate__animated animate__zoomIn">
        <i class="fa fa-chevron-left" onclick="beforeMovie()"></i>
    </div>
    <div class="blocks w-100">
        <div class="cart1 animate__animated animate__fadeInLeft"></div>
        <div class="cart2 animate__animated animate__fadeInDown"></div>
        <div class="cart3 animate__animated animate__fadeInRight"></div>
    </div>
    <div class="arrows animate__animated animate__zoomIn">
        <i class="fa fa-chevron-right" onclick="nextMovie()"></i>
    </div>`;
    headerr.style.height = "60vh";
    document.getElementById('twoHeader').innerText = "Expected Movies";
    document.getElementById('twoHeader').style.textAlign = "left";
    newMovies = undefined;
    temp = undefined;
    newMoviesImgPath = [];
    expectedMoviePage = 1;
    sr('GET', NEW_MOVIES_URL);
    newMovies = temp;
    while (newMovies == undefined) { }
    setPopularImg();
    document.querySelector('.allMovies').innerHTML = addedNewMovies();
    document.querySelector('#showMore').onclick = showMoreExpectedMovies;
    document.querySelector('#showMore').style.display = "block";
}
function allMoviesClick() {
    movies = undefined;
    temp = undefined;
    moviePage = 1;
    sr("GET", MOV_API_URL + moviePage + LST_EXT);
    movies = temp;
    let headerr = document.getElementById("headerr");
    let twoHeader = document.getElementById("twoHeader");
    headerr.innerHTML = `<h4 class="transition"><a href="#" id="homePage">Home</a> / All Movies</h4>`;
    headerr.style.height = "auto";
    twoHeader.innerText = "Browse all the movies";
    twoHeader.style.textAlign = "center";

    document.getElementById("allMovies").innerHTML = fillMovies();
    document.getElementById("showMore").onclick = showMoreAllMovies;
    document.getElementById("homePage").onclick = titleClick;
    document.querySelector('#showMore').style.display = "block";

}
function featuredClick() {
    movies = undefined;
    temp = undefined;
    moviePage = 1;
    sr("GET", MOV_API_URL + moviePage + LST_EXT);
    movies = temp;
    let headerr = document.getElementById("headerr");
    let twoHeader = document.getElementById("twoHeader");
    headerr.innerHTML = `<h4 class="transition"><a href="#" id="homePage">Home</a> / Featured</h4>`;
    headerr.style.height = "auto";
    twoHeader.innerText = "All Featured Movies";
    twoHeader.style.textAlign = "center";
    let content = fillMoviesFeatured();
    if (content.lenght == undefined) {
        let alMv = document.getElementById("allMovies");
        alMv.innerHTML = `<h2 style="text-align: center; color: white; width: 100%;">Movies Not Found</h2>`;
        alMv.style.textAlign = 'center';
        alMv.style.color = "white";
        alMv.style.width = "100%";
        document.getElementById("showMore").onclick = "";
    }
    else {
        document.getElementById("allMovies").innerHTML = content;
        document.getElementById("showMore").onclick = showMoreFeaturedMovies;
    }


    document.getElementById("homePage").onclick = titleClick;
    document.querySelector('#showMore').style.display = "block";
}
function researchGenre(movieType) {
    for (let i = 0; i < movieList.genres.length; i++) {
        const genre = movieList.genres[i];
        if (genre.name == movieType) {
            currentMovieType = genre.id;
            break;
        }
    }
    moviePage = 0;
    let headerr = document.getElementById("headerr");
    let twoHeader = document.getElementById("twoHeader");
    headerr.innerHTML = `<h4 class="transition"><a href="#" id="homePage">Home</a> / Genre: ${movieType}</h4>`;
    headerr.style.height = "auto";
    twoHeader.innerText = `Top results for: Genre: ${movieType}`;
    document.getElementById("allMovies").innerHTML = "";
    document.getElementById('showMore').onclick = fillGenreMovies;
    fillGenreMovies();
    document.getElementById("homePage").onclick = titleClick;
    document.querySelector('#showMore').style.display = "block";
}
function researchYear(movieYear) {
    currentMovieYear = movieYear;
    console.log(currentMovieYear);
    moviePage = 0;
    let headerr = document.getElementById("headerr");
    let twoHeader = document.getElementById("twoHeader");
    headerr.innerHTML = `<h4 class="transition"><a href="#" id="homePage" style="cursor: pointer;">Home</a> / Year: ${movieYear}</h4>`;
    headerr.style.height = "auto";
    twoHeader.innerText = `Top results for: Year: ${movieYear}`;
    document.getElementById("allMovies").innerHTML = "";
    document.getElementById('showMore').onclick = fillYearMovies;
    fillYearMovies();
    document.getElementById("homePage").onclick = titleClick;
    document.querySelector('#showMore').style.display = "block";
}

document.getElementById('genreID').onmouseenter = genreOrYearMouseEnterFunc;
document.getElementById('yearID').onmouseenter = genreOrYearMouseEnterFunc;
document.getElementById('genreID').onmouseleave = genreOrYearMouseLeaveFunc;
document.getElementById('yearID').onmouseleave = genreOrYearMouseLeaveFunc;
document.getElementById('searchBox').addEventListener('keydown', searchBoxFunc);
//-------------------------------------------------------------------------------------

//slider(Carousel)
let showedMovieArrID = 1;

function addedNewMovies() {
    let content = ``;

    newMovies.results.forEach(movie => {
        let path = "";
        if (movie.poster_path == null) path = "images/placeholder.gif";
        else path = "https://image.tmdb.org/t/p/w500/" + movie.poster_path;

        let detected = false;

        newMoviesImgPath.forEach(newMovie => {
            if (movie.poster_path == newMovie) {
                detected = true;
            }
        });

        if (!detected) {
            content += `
            <div class="newMovie">
                <img id="${movie.id}" src="${path}">
                <div class="moviePre">
                    <i class="far fa-play-circle"></i>
                </div>
                <div class="pre">
                    <p>${movie.original_title}</p>
                    <div class="otherPre">
                        <p>${movie.release_date.split('-')[0]}</p>
                            <i class="fa fa-star"></i>
                        <p>${movie.vote_average}</p>
                    </div>
                </div>
            </div>`;
            newMoviesImgPath.push(movie.poster_path);
        }
    });
    return content;
}
function setPopularImg() {
    if (popularityMovies != undefined) {
        let data = popularityMovies.results;
        let firstId = 0;
        let lastId = 0;
        if (showedMovieArrID - 1 == -1) firstId = data.length - 1;
        else firstId = showedMovieArrID - 1;
        if (showedMovieArrID + 1 == data.length) lastId = 0;
        else lastId = showedMovieArrID + 1;

        let content = `<img id="${data[firstId].id}" src="https://image.tmdb.org/t/p/w500/${data[firstId].poster_path}">`;
        document.querySelector('.cart1').innerHTML = content;
        let genre = "";
        data[showedMovieArrID].genre_ids.forEach(genre_id => {
            genre += movieListMap.get(genre_id) + ",";
        });
        genre = genre.slice(0, genre.length - 1);
        content = `<img id="${data[showedMovieArrID].id}" src="https://image.tmdb.org/t/p/w500/${data[showedMovieArrID].poster_path}">
        <div class="preview">
            <i class="far fa-play-circle"></i>
            <div class="info">
                <p >${data[showedMovieArrID].original_title}</p>
                <p >${data[showedMovieArrID].release_date.split('-')[0]}</p>
                <p >${genre}</p>
                <i class="fa fa-star"></i>
                <a>${data[showedMovieArrID].vote_average}</a>
            </div>
        </div>`;
        document.querySelector('.cart2').innerHTML = content;
        content = `<img id="${data[lastId].id}" src="https://image.tmdb.org/t/p/w500/${data[lastId].poster_path}">`;
        document.querySelector('.cart3').innerHTML = content;
    }
}
function nextMovie() {
    if (showedMovieArrID + 1 == popularityMovies.results.length) showedMovieArrID = 0;
    else showedMovieArrID += 1;

    setPopularImg();
}
function beforeMovie() {
    if (showedMovieArrID - 1 == -1) showedMovieArrID = popularityMovies.results.length - 1;
    else showedMovieArrID -= 1;

    setPopularImg();
}
function showMoreExpectedMovies() {
    expectedMoviePage++;
    sr('GET', `${BASE_URL}/discover/movie?${API_KEY}&language=en-US&sort_by=release_date.desc&include_adult=false&include_video=false&page=${expectedMoviePage}&with_watch_monetization_types=flatrate`);
    document.querySelector('.allMovies').innerHTML += addedNewMovies();
}
function showMoreAllMovies() {
    moviePage++;
    movies = undefined;
    temp = undefined;
    sr("GET", MOV_API_URL + moviePage + LST_EXT);
    movies = temp;
    document.getElementById('allMovies').innerHTML += fillMovies();
}
function showMoreFeaturedMovies() {
    moviePage++;
    movies = undefined;
    temp = undefined;
    sr("GET", MOV_API_URL + moviePage + LST_EXT);
    movies = temp;
    document.getElementById('allMovies').innerHTML += fillMoviesFeatured();
}
function queryFunc(x) {
    let searchBox = document.getElementById('searchForm');
    let searchBtn = document.getElementById('searchBtn');
    if (x.matches) {
        try {
            searchBox.classList.remove('w-50');
        } finally {
            searchBox.classList.add('w-75');
            searchBtn.style.display = "inline-block";
        }

        // document.getElementById('genreID').onclick = genreClickFunc;
        // document.getElementById('yearID').onclick = yearClickFunc;
    } else {
        try {
            searchBox.classList.remove('w-75');
        } finally {
            searchBox.classList.add('w-50');
            searchBtn.style.display = "none";
        }
        // document.getElementById('genreID').onclick = "";
        // document.getElementById('yearID').onclick = "";
    }
}
setTimeout(setYears, 1000);
var x = window.matchMedia("(max-width: 990px)")
queryFunc(x)
x.addListener(queryFunc);